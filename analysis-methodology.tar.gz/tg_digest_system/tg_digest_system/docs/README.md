# TG Digest System — Руководство по развёртыванию

## Содержание

1. [Что это за система](#1-что-это-за-система)
2. [Требования](#2-требования)
3. [Быстрый старт](#3-быстрый-старт)
4. [Подробная установка](#4-подробная-установка)
5. [Настройка Telegram](#5-настройка-telegram)
6. [Настройка каналов](#6-настройка-каналов)
7. [Написание промптов](#7-написание-промптов)
8. [Запуск системы](#8-запуск-системы)
9. [Мониторинг и логи](#9-мониторинг-и-логи)
10. [Решение проблем](#10-решение-проблем)
11. [FAQ](#11-faq)

---

## 1. Что это за система

**TG Digest System** — автоматическая система мониторинга Telegram-каналов с генерацией управленческих дайджестов.

### Что делает система:

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Telegram       │────▶│  PostgreSQL     │────▶│  OpenAI GPT     │
│  каналы         │     │  (хранение)     │     │  (анализ)       │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                                               │
        │                                               ▼
        │                                       ┌─────────────────┐
        │                                       │  Дайджест       │
        │                                       │  (Markdown)     │
        │                                       └─────────────────┘
        │                                               │
        ▼                                               ▼
┌─────────────────┐                             ┌─────────────────┐
│  OCR            │                             │  Рассылка       │
│  (Tesseract)    │                             │  в Telegram     │
└─────────────────┘                             └─────────────────┘
```

1. **Сбор сообщений** — читает новые сообщения из указанных Telegram-каналов
2. **OCR** — распознаёт текст на изображениях (скриншоты, фото)
3. **Анализ** — ChatGPT формирует краткий дайджест по специальному промпту
4. **Рассылка** — отправляет дайджест указанным получателям в Telegram

### Для кого:

- Руководители команд АСУДД
- Инженеры, которым нужно отслеживать несколько чатов
- Менеджеры проектов

---

## 2. Требования

### Сервер

| Параметр | Минимум | Рекомендуется |
|----------|---------|---------------|
| CPU | 1 ядро | 2 ядра |
| RAM | 1 GB | 2 GB |
| Диск | 10 GB | 20 GB |
| ОС | Ubuntu 22.04+ | Ubuntu 24.04 |

### Программное обеспечение

- **Docker** 24.0+ и **Docker Compose** 2.20+
- Доступ в интернет (Telegram API, OpenAI API)

### Аккаунты и ключи

| Что нужно | Где получить | Для чего |
|-----------|--------------|----------|
| Telegram API ID и Hash | https://my.telegram.org | Чтение каналов |
| Telegram Bot Token | https://t.me/BotFather | Отправка дайджестов |
| OpenAI API Key | https://platform.openai.com | Генерация дайджестов |

---

## 3. Быстрый старт

Если вы опытный пользователь, вот краткая инструкция:

```bash
# 1. Клонируем проект
git clone <repository> tg_digest_system
cd tg_digest_system

# 2. Копируем и заполняем .env
cp .env.example .env
nano .env  # Заполняем все переменные

# 3. Настраиваем каналы
nano config/channels.json

# 4. Авторизуемся в Telegram (один раз)
cd docker
docker-compose run --rm auth

# 5. Запускаем
docker-compose up -d

# 6. Смотрим логи
docker-compose logs -f worker
```

---

## 4. Подробная установка

### 4.1. Установка Docker (Ubuntu)

```bash
# Обновляем систему
sudo apt update && sudo apt upgrade -y

# Устанавливаем необходимые пакеты
sudo apt install -y ca-certificates curl gnupg

# Добавляем GPG ключ Docker
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

# Добавляем репозиторий
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Устанавливаем Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Добавляем текущего пользователя в группу docker (чтобы не писать sudo)
sudo usermod -aG docker $USER

# ВАЖНО: Перелогиньтесь или выполните:
newgrp docker

# Проверяем установку
docker --version
docker compose version
```

### 4.2. Скачивание проекта

```bash
# Создаём директорию для проекта
mkdir -p ~/projects
cd ~/projects

# Если есть git репозиторий:
git clone <repository_url> tg_digest_system

# Или распаковываем архив:
unzip tg_digest_system.zip
cd tg_digest_system
```

### 4.3. Структура проекта

```
tg_digest_system/
├── .env.example          # Шаблон переменных окружения
├── requirements.txt      # Python зависимости
│
├── config/
│   ├── channels.json     # ⚙️ Конфигурация каналов (РЕДАКТИРУЕМ)
│   └── channels.schema.json
│
├── prompts/              # 📝 Промпты для LLM (РЕДАКТИРУЕМ)
│   ├── asudd_main.md
│   ├── controllers.md
│   ├── detectors.md
│   └── api_integrations.md
│
├── scripts/              # Python код (не трогаем)
│   ├── config.py
│   ├── database.py
│   ├── telegram_client.py
│   ├── ocr.py
│   ├── llm.py
│   └── digest_worker.py
│
├── db/
│   ├── schema.sql        # Схема базы данных
│   └── init_db.sh
│
├── docker/
│   ├── Dockerfile
│   └── docker-compose.yml
│
└── docs/
    └── README.md         # Эта документация
```

---

## 5. Настройка Telegram

### 5.1. Получение API ID и API Hash

1. Откройте https://my.telegram.org
2. Войдите по номеру телефона
3. Перейдите в "API development tools"
4. Создайте новое приложение:
   - App title: `TG Digest System`
   - Short name: `tgdigest`
   - Platform: `Other`
5. Скопируйте **App api_id** и **App api_hash**

> ⚠️ **ВАЖНО**: Эти данные привязаны к вашему аккаунту. Не передавайте их третьим лицам!

### 5.2. Создание Telegram бота

1. Откройте https://t.me/BotFather
2. Отправьте `/newbot`
3. Введите имя бота: `ASUDD Digest Bot`
4. Введите username: `asudd_digest_bot` (должен быть уникальным)
5. Скопируйте **токен** (формат: `1234567890:ABCdefGHI...`)

> 💡 **Совет**: Также настройте описание бота через `/setdescription`

### 5.3. Получение ID получателей

Чтобы бот мог отправлять дайджесты, нужно знать Telegram ID пользователей.

**Способ 1: Через бота @userinfobot**
1. Откройте https://t.me/userinfobot
2. Отправьте любое сообщение
3. Бот покажет ваш ID

**Способ 2: Через @RawDataBot**
1. Откройте https://t.me/RawDataBot
2. Перешлите сообщение от нужного пользователя
3. В ответе найдите `"id":`

### 5.4. Получение ID каналов

**Способ 1: Через веб-версию**
1. Откройте https://web.telegram.org
2. Зайдите в нужный канал
3. В URL будет `#-1001234567890` — это ID (со знаком минус)

**Способ 2: Через пересылку в @RawDataBot**

> ⚠️ **Требование**: Ваш аккаунт должен быть участником канала!

---

## 6. Настройка каналов

### 6.1. Файл .env

Скопируйте шаблон и заполните:

```bash
cp .env.example .env
nano .env
```

Содержимое `.env`:

```bash
# Telegram API (с my.telegram.org)
TG_API_ID=12345678
TG_API_HASH=abcdef1234567890abcdef

# Telegram Bot (от BotFather)
TG_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz

# PostgreSQL (придумайте надёжный пароль)
PGDATABASE=tg_digest
PGUSER=tg_digest
PGPASSWORD=MyStr0ngP@ssw0rd!

# OpenAI (с platform.openai.com)
OPENAI_API_KEY=sk-proj-abcdefghijklmnop
OPENAI_MODEL=gpt-4o

# Часовой пояс
TZ=Europe/Moscow
```

### 6.2. Файл channels.json

Откройте `config/channels.json` и настройте:

```json
{
  "channels": [
    {
      "id": -1002700886173,
      "name": "АСУДД Основной",
      "description": "Главный канал команды",
      "enabled": true,
      "peer_type": "channel",
      "prompt_file": "prompts/asudd_main.md",
      "poll_interval_minutes": 30,
      "recipients": [
        {
          "telegram_id": 123456789,
          "name": "Иванов И.И.",
          "role": "lead",
          "send_file": true,
          "send_text": true
        },
        {
          "telegram_id": 987654321,
          "name": "Петров П.П.",
          "role": "manager",
          "send_file": true,
          "send_text": false
        }
      ]
    }
  ],
  
  "defaults": {
    "poll_interval_minutes": 30,
    "llm_provider": "openai",
    "llm_model": "gpt-4o",
    "ocr_enabled": true,
    "media_save_to_db": true
  }
}
```

### Пояснения к полям:

| Поле | Описание |
|------|----------|
| `id` | ID канала в Telegram (отрицательное число) |
| `name` | Человекочитаемое название |
| `enabled` | `true` — канал активен, `false` — отключён |
| `prompt_file` | Путь к файлу промпта |
| `recipients` | Список получателей дайджеста |
| `send_file` | Отправлять ли .md файл |
| `send_text` | Отправлять ли текст сообщением |

---

## 7. Написание промптов

Промпты находятся в папке `prompts/`. Каждый канал может иметь свой промпт.

### Структура промпта

```markdown
# Промпт: Название

## Роль
Кто ты и что делаешь

## Контекст предметной области
Термины, сокращения, типичные проблемы

## Формат дайджеста
Как должен выглядеть результат

## Правила
Что обязательно соблюдать

## Примеры
Хорошие и плохие примеры
```

### Советы по промптам:

1. **Будьте конкретны** — чем точнее описание, тем лучше результат
2. **Добавьте примеры** — LLM учится на примерах
3. **Укажите формат** — структура дайджеста должна быть чёткой
4. **Сохраняйте msg_id** — это важно для трассировки

---

## 8. Запуск системы

### 8.1. Первичная авторизация в Telegram

**Это нужно сделать один раз!**

```bash
cd docker
docker-compose run --rm auth
```

Введите:
1. Номер телефона (с кодом страны: +7...)
2. Код из Telegram
3. Пароль 2FA (если включён)

После успешной авторизации появится сообщение:
```
Авторизован как: Ваше Имя (ID: 123456789)
```

### 8.2. Запуск в Docker

```bash
cd docker

# Запуск в фоне
docker-compose up -d

# Проверка статуса
docker-compose ps

# Просмотр логов
docker-compose logs -f worker
```

### 8.3. Управление

```bash
# Остановка
docker-compose down

# Перезапуск
docker-compose restart worker

# Пересборка (после изменения кода)
docker-compose up -d --build worker

# Просмотр логов PostgreSQL
docker-compose logs postgres
```

### 8.4. Ручной запуск обработки

```bash
# Обработать все каналы один раз
docker-compose exec worker python /app/scripts/digest_worker.py --once

# Обработать конкретный канал
docker-compose exec worker python /app/scripts/digest_worker.py --channel -1002700886173 --once
```

---

## 9. Мониторинг и логи

### Логи воркера

```bash
# Последние 100 строк
docker-compose logs --tail 100 worker

# Следить за логами в реальном времени
docker-compose logs -f worker

# Сохранить логи в файл
docker-compose logs worker > worker.log
```

### Подключение к базе данных

```bash
# Через docker
docker-compose exec postgres psql -U tg_digest -d tg_digest

# Полезные запросы:

-- Сколько сообщений собрано
SELECT peer_id, COUNT(*) as cnt FROM tg.messages GROUP BY peer_id;

-- Последние дайджесты
SELECT id, peer_id, msg_id_from, msg_id_to, created_at 
FROM rpt.digests ORDER BY created_at DESC LIMIT 10;

-- Статистика доставки
SELECT status, COUNT(*) FROM rpt.deliveries GROUP BY status;

-- Состояние курсоров
SELECT * FROM rpt.report_state;
```

---

## 10. Решение проблем

### Проблема: "TG_API_ID не установлен"

**Причина**: Не заполнен файл `.env`

**Решение**:
```bash
cp .env.example .env
nano .env  # Заполните все переменные
```

### Проблема: "FloodWaitError"

**Причина**: Telegram временно заблокировал из-за частых запросов

**Решение**: Подождите указанное время (обычно 5-30 минут)

### Проблема: "Could not find the input entity"

**Причина**: Аккаунт не состоит в канале или неверный ID

**Решение**:
1. Убедитесь, что ваш аккаунт — участник канала
2. Проверьте ID канала (должен начинаться с `-100`)

### Проблема: "OpenAI API error: insufficient_quota"

**Причина**: Закончился баланс OpenAI

**Решение**: Пополните баланс на https://platform.openai.com/account/billing

### Проблема: OCR не работает

**Проверка**:
```bash
docker-compose exec worker tesseract --version
```

Если ошибка — пересоберите контейнер:
```bash
docker-compose build --no-cache worker
```

### Проблема: Бот не отправляет сообщения

**Причина**: Пользователь не начал диалог с ботом

**Решение**: Каждый получатель должен написать `/start` боту

---

## 11. FAQ

### Q: Как добавить новый канал?

1. Откройте `config/channels.json`
2. Добавьте новый объект в массив `channels`
3. Перезапустите: `docker-compose restart worker`

### Q: Как изменить интервал опроса?

В `docker-compose.yml` измените команду:
```yaml
command: ["--interval", "15"]  # 15 минут
```

### Q: Как отключить OCR?

В `config/channels.json`:
```json
"defaults": {
  "ocr_enabled": false
}
```

### Q: Как посмотреть сгенерированные дайджесты?

```sql
SELECT digest_llm FROM rpt.digests ORDER BY created_at DESC LIMIT 1;
```

### Q: Система безопасна?

- Все секреты хранятся в `.env` (не коммитьте в git!)
- Используется отдельный пользователь в контейнере
- PostgreSQL доступен только локально

### Q: Сколько стоит OpenAI?

GPT-4o: ~$5 за 1M входных токенов, ~$15 за 1M выходных.
Один дайджест ≈ 2000-5000 токенов ≈ $0.01-0.05

---

## Контакты

При возникновении вопросов обращайтесь к администратору системы.
