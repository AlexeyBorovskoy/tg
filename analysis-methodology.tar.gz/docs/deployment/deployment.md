# Развёртывание

## ОС
Ubuntu 24.04 LTS

## Пакеты
- python3
- postgresql
- tesseract-ocr
- tesseract-ocr-rus
- tesseract-ocr-eng

## Python
venv + requirements проекта

## Systemd
- tg-poll.service
