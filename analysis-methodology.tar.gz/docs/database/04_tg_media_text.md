# tg.media_text

Результаты OCR-распознавания изображений.

## Поля
- peer_type TEXT
- peer_id BIGINT
- msg_id BIGINT
- ocr_text TEXT
- created_at TIMESTAMPTZ

## Источник
Tesseract OCR (rus + eng)
